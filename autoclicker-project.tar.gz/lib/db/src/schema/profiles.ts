import { boolean, integer, pgTable, text } from "drizzle-orm/pg-core";

export const profilesTable = pgTable("autoclicker_profiles", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  intervalMs: integer("interval_ms").notNull(),
  clicks: integer("clicks").notNull().default(0),
  isDefault: boolean("is_default").notNull().default(false),
});

export type Profile = typeof profilesTable.$inferSelect;
export type NewProfile = typeof profilesTable.$inferInsert;