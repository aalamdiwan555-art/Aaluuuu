import { Router, type IRouter } from "express";
import healthRouter from "./health";
import autoclickerRouter from "./autoclicker";

const router: IRouter = Router();

router.use(healthRouter);
router.use(autoclickerRouter);

export default router;
