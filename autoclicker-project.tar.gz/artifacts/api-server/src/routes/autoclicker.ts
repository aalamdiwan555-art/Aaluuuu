import { Router, type Request, type Response } from "express";
import { createHash, randomBytes, randomUUID, scrypt as nodeScrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, desc, eq } from "drizzle-orm";
import {
  CreateProfileBody,
  LoginBody,
  SignupBody,
  StartAutoclickerBody,
  UpdateProfileBody,
  UpdateUserApprovalBody,
  UpdateUserSubscriptionBody,
} from "@workspace/api-zod";
import { db, profilesTable, usersTable, type User } from "@workspace/db";

const router = Router();
const scrypt = promisify(nodeScrypt);
const sessions = new Map<string, string>();
const running = new Map<string, { startedAt: Date; clicks: number }>();
const sessionCookie = "autoclicker_session";

type SubscriptionPlan = "none" | "one_day" | "two_days" | "three_days" | "lifetime";
type AccountStatus = "pending" | "approved" | "declined";

function subscriptionFor(user: User) {
  const active = user.plan === "lifetime" ||
    (user.status === "approved" && Boolean(user.expiresAt) && user.expiresAt!.getTime() > Date.now());
  return {
    plan: user.plan as SubscriptionPlan,
    active,
    expiresAt: user.expiresAt?.toISOString() ?? null,
  };
}

function presentUser(user: User) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role as "user" | "admin",
    status: user.status as AccountStatus,
    subscription: subscriptionFor(user),
  };
}

function presentAdminUser(user: User) {
  return { ...presentUser(user), createdAt: user.createdAt.toISOString() };
}

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt}:${derived.toString("hex")}`;
}

async function checkPassword(password: string, stored: string) {
  const [salt, expectedHex] = stored.split(":");
  if (!salt || !expectedHex) return false;
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  const expected = Buffer.from(expectedHex, "hex");
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}

async function ensureAdmin() {
  const email = process.env.AUTOCLICKER_ADMIN_EMAIL ?? "aalamdiwan555@gmail.com";
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing[0]) return existing[0];
  const password = process.env.AUTOCLICKER_ADMIN_PASSWORD;
  if (!password) return null;
  const [admin] = await db.insert(usersTable).values({
    id: randomUUID(),
    name: "Admin",
    email,
    passwordHash: await hashPassword(password),
    role: "admin",
    status: "approved",
    plan: "lifetime",
  }).returning();
  return admin;
}

async function userFromRequest(req: Request) {
  const id = req.cookies?.[sessionCookie];
  const userId = id ? sessions.get(id) : undefined;
  if (!userId) return null;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  return user ?? null;
}

function setSession(res: Response, userId: string) {
  const token = randomBytes(32).toString("hex");
  sessions.set(token, userId);
  res.cookie(sessionCookie, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 30,
  });
}

function badRequest(res: Response, message: string) {
  return res.status(400).json({ error: message });
}

async function requireUser(req: Request, res: Response) {
  const user = await userFromRequest(req);
  if (!user) {
    res.status(401).json({ error: "Please log in to continue." });
    return null;
  }
  return user;
}

async function requireAdmin(req: Request, res: Response) {
  const user = await requireUser(req, res);
  if (!user) return null;
  if (user.role !== "admin") {
    res.status(403).json({ error: "Admin access is required." });
    return null;
  }
  return user;
}

router.post("/auth/signup", async (req, res) => {
  const parsed = SignupBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Please provide a valid name, email, and password.");
  const email = parsed.data.email.trim().toLowerCase();
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing[0]) return res.status(409).json({ error: "An account with that email already exists." });
  const [user] = await db.insert(usersTable).values({
    id: randomUUID(),
    name: parsed.data.name.trim(),
    email,
    passwordHash: await hashPassword(parsed.data.password),
    role: "user",
    status: "pending",
    plan: "none",
  }).returning();
  await db.insert(profilesTable).values({
    id: randomUUID(),
    userId: user.id,
    name: "Default profile",
    intervalMs: 100,
    clicks: 0,
    isDefault: true,
  });
  setSession(res, user.id);
  return res.status(201).json({
    user: presentUser(user),
    message: "Your account is pending admin approval.",
  });
});

router.post("/auth/login", async (req, res) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Please provide a valid email and password.");
  await ensureAdmin();
  const email = parsed.data.email.trim().toLowerCase();
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (!user || !(await checkPassword(parsed.data.password, user.passwordHash))) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }
  setSession(res, user.id);
  return res.json({ user: presentUser(user) });
});

router.post("/auth/logout", async (req, res) => {
  const token = req.cookies?.[sessionCookie];
  if (token) sessions.delete(token);
  res.clearCookie(sessionCookie);
  return res.status(204).send();
});

router.get("/auth/me", async (req, res) => {
  const user = await userFromRequest(req);
  if (!user) return res.status(401).json({ error: "Not authenticated." });
  return res.json(presentUser(user));
});

router.get("/dashboard/summary", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const [profile] = await db.select().from(profilesTable)
    .where(and(eq(profilesTable.userId, user.id), eq(profilesTable.isDefault, true))).limit(1);
  return res.json({
    status: user.status,
    subscription: subscriptionFor(user),
    totalClicks: user.totalClicks,
    activeProfile: profile?.name ?? null,
  });
});

router.get("/profiles", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const profiles = await db.select().from(profilesTable).where(eq(profilesTable.userId, user.id));
  return res.json(profiles);
});

router.post("/profiles", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const parsed = CreateProfileBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Please provide a profile name and interval of at least 10ms.");
  if (parsed.data.isDefault) {
    await db.update(profilesTable).set({ isDefault: false }).where(eq(profilesTable.userId, user.id));
  }
  const [profile] = await db.insert(profilesTable).values({
    id: randomUUID(),
    userId: user.id,
    name: parsed.data.name.trim(),
    intervalMs: parsed.data.intervalMs,
    clicks: parsed.data.clicks ?? 0,
    isDefault: parsed.data.isDefault ?? false,
  }).returning();
  return res.status(201).json(profile);
});

router.patch("/profiles/:id", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Please provide valid profile values.");
  if (parsed.data.isDefault) {
    await db.update(profilesTable).set({ isDefault: false }).where(eq(profilesTable.userId, user.id));
  }
  const [profile] = await db.update(profilesTable).set(parsed.data)
    .where(and(eq(profilesTable.id, req.params.id), eq(profilesTable.userId, user.id))).returning();
  if (!profile) return res.status(404).json({ error: "Profile not found." });
  return res.json(profile);
});

router.delete("/profiles/:id", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  await db.delete(profilesTable).where(and(eq(profilesTable.id, req.params.id), eq(profilesTable.userId, user.id)));
  return res.status(204).send();
});

router.post("/autoclicker/start", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const subscription = subscriptionFor(user);
  if (user.status !== "approved") {
    return res.status(403).json({ error: user.status === "pending" ? "Your account is waiting for admin approval." : "Your account was declined." });
  }
  if (!subscription.active) return res.status(403).json({ error: "Your subscription has expired. Please renew to start the autoclicker." });
  const parsed = StartAutoclickerBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Choose a click profile first.");
  const [profile] = await db.select().from(profilesTable)
    .where(and(eq(profilesTable.id, parsed.data.profileId), eq(profilesTable.userId, user.id))).limit(1);
  if (!profile) return res.status(404).json({ error: "Profile not found." });
  const state = { startedAt: new Date(), clicks: profile.clicks };
  running.set(user.id, state);
  return res.json({ running: true, clicks: state.clicks, startedAt: state.startedAt.toISOString(), message: `Running ${profile.name}` });
});

router.post("/autoclicker/stop", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;
  const state = running.get(user.id);
  if (state) {
    await db.update(usersTable).set({ totalClicks: user.totalClicks + state.clicks }).where(eq(usersTable.id, user.id));
    running.delete(user.id);
  }
  return res.json({ running: false, clicks: state?.clicks ?? 0, startedAt: state?.startedAt.toISOString() ?? null, message: "Autoclicker stopped." });
});

router.get("/admin/users", async (req, res) => {
  await ensureAdmin();
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const users = await db.select().from(usersTable).orderBy(desc(usersTable.createdAt));
  return res.json(users.map(presentAdminUser));
});

router.patch("/admin/users/:id/approval", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const parsed = UpdateUserApprovalBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Choose pending, approved, or declined.");
  const [user] = await db.update(usersTable).set({ status: parsed.data.status })
    .where(eq(usersTable.id, req.params.id)).returning();
  if (!user) return res.status(404).json({ error: "User not found." });
  return res.json(presentAdminUser(user));
});

router.patch("/admin/users/:id/subscription", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const parsed = UpdateUserSubscriptionBody.safeParse(req.body);
  if (!parsed.success) return badRequest(res, "Choose a subscription duration.");
  const plan = parsed.data.plan as SubscriptionPlan;
  const expiresAt = plan === "lifetime" || plan === "none" ? null : new Date(Date.now() + ({
    one_day: 1,
    two_days: 2,
    three_days: 3,
  }[plan] ?? 0) * 24 * 60 * 60 * 1000);
  const [user] = await db.update(usersTable).set({ plan, expiresAt })
    .where(eq(usersTable.id, req.params.id)).returning();
  if (!user) return res.status(404).json({ error: "User not found." });
  return res.json(presentAdminUser(user));
});

export default router;